(function () {

/* Imports */
var DDP = Package['ddp-client'].DDP;
var DDPServer = Package['ddp-server'].DDPServer;

/* Package-scope variables */
var LivedataTest;



/* Exports */
Package._define("livedata", {
  DDP: DDP,
  DDPServer: DDPServer,
  LivedataTest: LivedataTest
});

})();
